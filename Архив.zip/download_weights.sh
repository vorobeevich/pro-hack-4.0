#!/bin/bash

wget https://pjreddie.com/media/files/yolov3.weights
